--
-- PostgreSQL database dump
--

\restrict h6a7Rv8IPPO8507pcI4r8nVieAEcs22ssCc2I6AlLfTVNAqEVsq9pp4cWmrHoMc

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_years (
    id uuid NOT NULL,
    name text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    before jsonb,
    after jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courses (
    id uuid NOT NULL,
    program_id uuid,
    code text NOT NULL,
    title text NOT NULL,
    credit_hours integer NOT NULL,
    category text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id uuid NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL,
    head_user_id uuid
);


--
-- Name: document_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_verifications (
    id uuid NOT NULL,
    code text NOT NULL,
    document_kind text NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    subject_label text NOT NULL,
    issued_by uuid,
    revoked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    owner_type text NOT NULL,
    owner_id uuid NOT NULL,
    document_type text NOT NULL,
    original_filename text NOT NULL,
    storage_key text NOT NULL,
    mime_type text NOT NULL,
    size_bytes integer NOT NULL,
    checksum text,
    uploaded_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(3) without time zone
);


--
-- Name: emergency_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.emergency_contacts (
    id uuid NOT NULL,
    employee_id uuid NOT NULL,
    name text NOT NULL,
    relationship text,
    phone_number text NOT NULL,
    address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: employee_education; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_education (
    id uuid NOT NULL,
    employee_id uuid NOT NULL,
    institution text NOT NULL,
    qualification text NOT NULL,
    field_of_study text,
    graduation_year integer,
    gpa text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: employee_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_number_sequences (
    year integer NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: employee_qualifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_qualifications (
    id uuid NOT NULL,
    employee_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    issuer text,
    issue_date date,
    expiry_date date,
    reference_no text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id uuid NOT NULL,
    employee_number text NOT NULL,
    first_name text NOT NULL,
    middle_name text,
    last_name text NOT NULL,
    gender text NOT NULL,
    date_of_birth date NOT NULL,
    nationality text,
    marital_status text,
    national_id text NOT NULL,
    tax_id text,
    phone_number text NOT NULL,
    email text NOT NULL,
    address text,
    department_id uuid NOT NULL,
    "position" text NOT NULL,
    employment_type text NOT NULL,
    contract_type text,
    employment_status text NOT NULL,
    date_of_employment date NOT NULL,
    contract_end_date date,
    salary_grade text,
    office_location text,
    supervisor_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL,
    photo_storage_key text
);


--
-- Name: employment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employment_history (
    id uuid NOT NULL,
    employee_id uuid NOT NULL,
    employer text NOT NULL,
    "position" text NOT NULL,
    start_date date,
    end_date date,
    responsibilities text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrollments (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    section_id uuid NOT NULL,
    status text DEFAULT 'enrolled'::text NOT NULL,
    attempt_number integer DEFAULT 1 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    deleted_at timestamp(3) without time zone
);


--
-- Name: grade_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grade_components (
    id uuid NOT NULL,
    name text NOT NULL,
    weight_percent double precision NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    department_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    max_score double precision DEFAULT 100 NOT NULL
);


--
-- Name: grade_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grade_entries (
    id uuid NOT NULL,
    enrollment_id uuid NOT NULL,
    component_id uuid NOT NULL,
    score double precision NOT NULL,
    max_score double precision NOT NULL,
    entered_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: grade_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grade_results (
    id uuid NOT NULL,
    enrollment_id uuid NOT NULL,
    percentage double precision,
    letter text,
    grade_point double precision,
    is_pass boolean,
    applied_snapshot jsonb,
    published_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: grade_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grade_submissions (
    id uuid NOT NULL,
    section_id uuid NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    submitted_by uuid,
    submitted_at timestamp(3) without time zone,
    approved_by uuid,
    approved_at timestamp(3) without time zone,
    published_by uuid,
    published_at timestamp(3) without time zone,
    locked_at timestamp(3) without time zone,
    returned_by uuid,
    return_reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: grading_scale_bands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grading_scale_bands (
    id uuid NOT NULL,
    scale_id uuid NOT NULL,
    min_percent double precision NOT NULL,
    max_percent double precision NOT NULL,
    letter text NOT NULL,
    grade_point double precision NOT NULL,
    is_pass boolean DEFAULT true NOT NULL
);


--
-- Name: grading_scales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grading_scales (
    id uuid NOT NULL,
    name text NOT NULL,
    department_id uuid,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    pass_mark double precision DEFAULT 50 NOT NULL,
    rounding text DEFAULT 'half_up'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone
);


--
-- Name: instructor_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instructor_assignments (
    id uuid NOT NULL,
    section_id uuid NOT NULL,
    instructor_id uuid NOT NULL,
    assigned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    assigned_by uuid
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    key text NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: programs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programs (
    id uuid NOT NULL,
    department_id uuid NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    degree_level text NOT NULL,
    duration_years integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    revoked_at timestamp(3) without time zone,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name text NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id uuid NOT NULL,
    course_id uuid NOT NULL,
    semester_id uuid NOT NULL,
    section_label text NOT NULL,
    capacity integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: semesters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.semesters (
    id uuid NOT NULL,
    academic_year_id uuid NOT NULL,
    name text NOT NULL,
    sequence integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status text DEFAULT 'planned'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: student_number_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_number_sequences (
    year integer NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id uuid NOT NULL,
    student_number text NOT NULL,
    first_name text NOT NULL,
    middle_name text,
    last_name text NOT NULL,
    gender text NOT NULL,
    date_of_birth date,
    email text,
    phone_number text,
    department_id uuid NOT NULL,
    program_id uuid NOT NULL,
    batch text,
    section text,
    current_semester_id uuid,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL,
    photo_storage_key text
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    description text,
    updated_by uuid,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp(3) without time zone,
    token_version integer DEFAULT 0 NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone,
    version integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
aa2496b4-e355-4dca-8989-0c559c146e6e	bf50924ddd28a2f3b01d98c544b2b08bcfa64457f4aa9968708d86f26d3c6a51	2026-08-08 14:11:06.860878+00	20260808130126_init_identity_access	\N	\N	2026-08-08 14:11:03.490879+00	1
c038dbd0-971d-4ee5-b62d-18285567c63a	e392921609362eb172bb4e3af6d0bc68c03eb48c3cdc6d08e296a79e08c1e186	2026-08-08 15:11:48.892727+00	20260808143236_academic_structure	\N	\N	2026-08-08 15:11:45.519023+00	1
6f492759-4f85-4baf-aedf-efeb5db54b08	67e384ddb7ed1e6bd5d3bd17629368d1976037772d2cb54c3512b8b219bed59a	2026-08-08 16:24:51.499341+00	20260808161202_employee_management	\N	\N	2026-08-08 16:24:50.154929+00	1
40430452-56a5-4e61-abc9-9431ea57cb3a	53a7108961d5045bafef864f74d2c02187d22bce15f258ab30a35d712550dd1e	2026-08-08 17:02:18.307796+00	20260808165527_employee_subrecords	\N	\N	2026-08-08 17:02:16.07838+00	1
bf3aacfa-35f9-421d-9fa9-5f1b15b28c57	c1f11753a59a7af8a677fd9abe49fd3860b1b3b0dcdd7fdfcfe62a8936dd3a11	2026-08-08 17:27:56.598654+00	20260808171614_documents	\N	\N	2026-08-08 17:27:55.523685+00	1
c21ae606-3bef-46af-9195-7be2f44b6fca	751bde3c4bfe8374beaf32ccd65c0ea7c97ab4c83dee1cef3c9474136483597a	2026-08-08 18:21:41.366665+00	20260808175700_settings_and_verification	\N	\N	2026-08-08 18:21:40.632366+00	1
2741b1dc-525a-4a6b-b29e-206a4e9846e1	e458d62fab5736f7abab203cba611c430709a068213dccf107bfd6c64e17813a	2026-08-08 19:10:37.652711+00	20260808190149_employee_photo	\N	\N	2026-08-08 19:10:37.179069+00	1
5aa6b68f-a11c-49a9-9928-5977702b0929	2f6d84f86f829e83a5a6082b5757f60eaa1daffd2f12e21ea317605872df9271	2026-08-08 19:37:12.977755+00	20260808192325_student_academic_management	\N	\N	2026-08-08 19:37:08.38151+00	1
4bb964ca-8869-4882-b47f-2ff0f1896cc0	ff6c2aa8e12d2c07057b2b9fa19682b711779be5c2d91e17b92761c5fa48e699	2026-08-08 20:35:40.401377+00	20260808200614_grading_configuration	\N	\N	2026-08-08 20:35:39.237797+00	1
38b21f6f-163f-4627-be5e-ec740062c239	8ee55a9f7e5af41e1e589a8716f28e4afdcfc9d85b25a88672538fe4985c8a7f	2026-08-08 20:55:17.730802+00	20260808204600_grade_entry_workflow	\N	\N	2026-08-08 20:55:16.075947+00	1
56936515-6f73-4e57-a3c9-b9fe4d26529b	1fa35624d8caec92078c6e9774683c7e8ac4bccd810a2cba67b990dba13b7660	2026-08-08 20:55:17.984328+00	20260808204654_department_head	\N	\N	2026-08-08 20:55:17.784008+00	1
2159499a-4dec-46af-a5c4-dff940fb20c2	3cef662d50b1728cdfcf41a226a1c028b33b5cf488797820d8f1cf9d6e25f42c	2026-08-08 21:37:19.533296+00	20260808210832_component_max_score	\N	\N	2026-08-08 21:37:19.390018+00	1
8aa1a7eb-6809-43a8-8f96-60599a7e5b99	ccad63225d62533efa83aa858ef33694e8ff7c953bc5bdccaa632d7a89c6f4fe	2026-08-08 23:21:35.528034+00	20260808224147_student_photo	\N	\N	2026-08-08 23:21:35.344847+00	1
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_years (id, name, start_date, end_date, is_current, created_at, updated_at, created_by, updated_by, deleted_at, version) FROM stdin;
bcab514a-2cd1-4e44-a5a8-7096f73a245d	2018/2019	2018-01-08	2018-11-30	t	2026-08-08 15:40:18.596	2026-08-08 15:40:25.037	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, entity_type, entity_id, before, after, ip_address, user_agent, created_at) FROM stdin;
5d2f724c-c0b9-404e-b4cd-fbf93eb540c4	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:19:22.819
19084401-2452-4cdf-842c-653958827e80	845524a5-2d8d-47e0-a279-476df7c604c7	auth.password.changed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:20:20.272
33c02921-3e96-4951-bf15-b1dfc3e82719	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:20:20.371
10e14821-f85d-46fe-a5f8-ddfc0d4238e8	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:21:11.248
54149df3-4f61-4bf0-8444-c1a8a43d14ef	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:24:15.963
bd147f3e-cefd-49d2-9125-43bb791f5d9d	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:43:54.555
1fbd06e7-556c-445e-958f-981e71a08070	845524a5-2d8d-47e0-a279-476df7c604c7	department.create	Department	6a6a99a5-0dd3-4180-9bd9-5fe5aef14dbf	\N	{"id": "6a6a99a5-0dd3-4180-9bd9-5fe5aef14dbf", "code": "BM", "name": "Beket Mitiku", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:14:56.099Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:14:56.099Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:14:56.178
d106d9e5-d40d-4830-b79e-b908d8bb7def	845524a5-2d8d-47e0-a279-476df7c604c7	department.create	Department	a93a3405-de29-41f7-ae4e-860536f98366	\N	{"id": "a93a3405-de29-41f7-ae4e-860536f98366", "code": "BMD", "name": "Beket Mitiku Amenu", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:15:27.509Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:15:27.509Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:15:27.635
c604ee53-b40f-46a5-8668-37e058d100ba	845524a5-2d8d-47e0-a279-476df7c604c7	department.delete	Department	a93a3405-de29-41f7-ae4e-860536f98366	{"id": "a93a3405-de29-41f7-ae4e-860536f98366", "code": "BMD", "name": "Beket Mitiku Amenu", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:15:27.509Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:15:27.509Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:15:43.109
5cc37fd9-9eb5-462d-9e85-9b5921f838fe	845524a5-2d8d-47e0-a279-476df7c604c7	department.delete	Department	6a6a99a5-0dd3-4180-9bd9-5fe5aef14dbf	{"id": "6a6a99a5-0dd3-4180-9bd9-5fe5aef14dbf", "code": "BM", "name": "Beket Mitiku", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:14:56.099Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:14:56.099Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:16:12.066
83e88f05-7ca9-4117-9de8-c3f1beb4945a	845524a5-2d8d-47e0-a279-476df7c604c7	department.create	Department	a104db70-d76b-4061-9f72-51d2d574605b	\N	{"id": "a104db70-d76b-4061-9f72-51d2d574605b", "code": "PE", "name": "Python Engineering", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:37:47.419Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:37:47.419Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:37:48.468
3de8aafa-2d46-4a85-85bf-4531097f3a24	845524a5-2d8d-47e0-a279-476df7c604c7	program.create	Program	18804f06-c453-4a08-af69-8888fb80b8f5	\N	{"id": "18804f06-c453-4a08-af69-8888fb80b8f5", "code": "BETT", "name": "DEpartment head", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:38:43.463Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:38:43.463Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "degreeLevel": "Degree", "departmentId": "a104db70-d76b-4061-9f72-51d2d574605b", "durationYears": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:38:44.066
cf063e6a-a00f-4fa2-a757-b6e867ef1598	845524a5-2d8d-47e0-a279-476df7c604c7	academic-year.create	AcademicYear	bcab514a-2cd1-4e44-a5a8-7096f73a245d	\N	{"id": "bcab514a-2cd1-4e44-a5a8-7096f73a245d", "name": "2018/2019", "endDate": "2018-11-30T00:00:00.000Z", "version": 0, "createdAt": "2026-08-08T15:40:18.596Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "isCurrent": false, "startDate": "2018-01-08T00:00:00.000Z", "updatedAt": "2026-08-08T15:40:18.596Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:40:19.174
097a1ecc-7631-4ab9-8458-f409553e9b06	845524a5-2d8d-47e0-a279-476df7c604c7	academic-year.set-current	AcademicYear	bcab514a-2cd1-4e44-a5a8-7096f73a245d	\N	{"isCurrent": true}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:40:26.205
b98e21c0-8664-4d2f-a45b-dee620a9ed31	845524a5-2d8d-47e0-a279-476df7c604c7	semester.create	Semester	bcbab3f7-fee5-4fa0-bca1-914b3a60a822	\N	{"id": "bcbab3f7-fee5-4fa0-bca1-914b3a60a822", "name": "Semester 1", "status": "active", "endDate": "2018-06-08T00:00:00.000Z", "version": 0, "sequence": 1, "createdAt": "2026-08-08T15:41:26.068Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "startDate": "2018-01-08T00:00:00.000Z", "updatedAt": "2026-08-08T15:41:26.068Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "academicYearId": "bcab514a-2cd1-4e44-a5a8-7096f73a245d"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 15:41:27.543
53cac7b4-b89e-4f3b-8686-d77e611f8f45	845524a5-2d8d-47e0-a279-476df7c604c7	user.reset-password	User	845524a5-2d8d-47e0-a279-476df7c604c7	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:01:51.992
e36cc4ad-9710-4b5c-91cd-c424a436e6f4	845524a5-2d8d-47e0-a279-476df7c604c7	user.update	User	845524a5-2d8d-47e0-a279-476df7c604c7	{"roles": ["system_administrator"], "isActive": true}	{"roles": ["1f5e5f1a-04ef-4d8e-9704-32debcdcce6f"], "isActive": true}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:02:08.693
7c688caf-6c80-4744-b836-7a1977b18830	845524a5-2d8d-47e0-a279-476df7c604c7	user.create	User	3aada072-6af7-440f-b53d-4fd66be62a3a	\N	{"email": "beketmitiku@gmail.com", "roles": ["ac0ce30a-9b7a-4872-b7d4-97806fb6e494"]}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:02:48.509
3f8c08ad-2f41-4ea0-8f84-369865439da8	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:26:11.049
e494eaa4-afa9-4664-bc6b-4bc725cd542b	845524a5-2d8d-47e0-a279-476df7c604c7	auth.password.changed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:27:10.528
0e285992-e826-4522-9772-06ecfc9a6aae	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:27:10.613
d6112b4c-355b-44c8-86c9-24e9defedb2f	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:27:26.471
e3ccdac1-23cf-4d71-a5a0-e8a759ea34b5	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:29:33.479
9b33ead8-1669-4a19-963d-15f1b5546e3d	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:29:59.264
0bc0b364-6e63-4454-bc39-afbd355cb2d4	845524a5-2d8d-47e0-a279-476df7c604c7	department.create	Department	520548b2-a7cc-49ef-a8dd-72bc632f7733	\N	{"id": "520548b2-a7cc-49ef-a8dd-72bc632f7733", "code": "FM", "name": "Farming", "version": 0, "isActive": true, "createdAt": "2026-08-08T16:30:20.575Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T16:30:20.575Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:30:21.861
b762dd79-6f91-489c-86ad-ad3f79dc39df	845524a5-2d8d-47e0-a279-476df7c604c7	department.update	Department	520548b2-a7cc-49ef-a8dd-72bc632f7733	{"id": "520548b2-a7cc-49ef-a8dd-72bc632f7733", "code": "FM", "name": "Farming", "version": 0, "isActive": true, "createdAt": "2026-08-08T16:30:20.575Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T16:30:20.575Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	{"id": "520548b2-a7cc-49ef-a8dd-72bc632f7733", "code": "FM", "name": "Farming", "version": 1, "isActive": true, "createdAt": "2026-08-08T16:30:20.575Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T16:35:06.319Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:35:06.475
6f3d59e1-8870-4b1e-a88f-5d6fc68e4e5a	845524a5-2d8d-47e0-a279-476df7c604c7	department.update	Department	a104db70-d76b-4061-9f72-51d2d574605b	{"id": "a104db70-d76b-4061-9f72-51d2d574605b", "code": "PE", "name": "Python Engineering", "version": 0, "isActive": true, "createdAt": "2026-08-08T15:37:47.419Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T15:37:47.419Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	{"id": "a104db70-d76b-4061-9f72-51d2d574605b", "code": "PE", "name": "Python Engineering", "version": 1, "isActive": false, "createdAt": "2026-08-08T15:37:47.419Z", "createdBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "deletedAt": null, "updatedAt": "2026-08-08T16:35:14.905Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "description": null}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:35:15.027
c185ba88-336f-4e7a-9d82-011fb8e6e0b6	845524a5-2d8d-47e0-a279-476df7c604c7	user.update	User	3aada072-6af7-440f-b53d-4fd66be62a3a	{"roles": ["dean"], "isActive": true}	{"roles": ["ac0ce30a-9b7a-4872-b7d4-97806fb6e494"], "isActive": true}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:35:36.49
cfa1f908-9c25-477d-a889-2f7f698606a5	845524a5-2d8d-47e0-a279-476df7c604c7	user.reset-password	User	3aada072-6af7-440f-b53d-4fd66be62a3a	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:35:45.305
116bd8cb-5c94-4108-9e5c-5399752b02fc	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:36:21.662
b53dd5af-78eb-4cc9-a4a4-dff08d1002e9	3aada072-6af7-440f-b53d-4fd66be62a3a	auth.login.failed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:36:37.526
4b1b1f9f-0123-4b76-9896-5c5bef3a6f02	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:44:41.644
17acd300-8a78-446c-963c-545d9bccc26b	845524a5-2d8d-47e0-a279-476df7c604c7	employee.create	Employee	3e5f19f0-472b-43af-8d2e-95dad613f925	\N	{"name": "Beket Amenu", "employeeNumber": "DBPC-EMP-2026-00001"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:46:28.664
fa95f0d6-62d5-43df-abc0-8d0021a48f92	845524a5-2d8d-47e0-a279-476df7c604c7	education.create	EmployeeEducation	00fd2505-66f5-499c-b017-b8a7a172a3a0	\N	{"employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:03:56.761
7ea95518-ee13-4310-b5d4-d2b300096072	845524a5-2d8d-47e0-a279-476df7c604c7	education.create	EmployeeEducation	f887af24-c200-4c0d-86af-4295351d455c	\N	{"employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:04:20.243
8d1a435b-978b-40d6-8a8e-2e8fa4d57449	845524a5-2d8d-47e0-a279-476df7c604c7	qualification.create	EmployeeQualification	4dfa9fcf-3304-4111-98c8-9db1a0f22535	\N	{"employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:05:03.299
bd32faed-77c0-4419-ac8d-53ae4c15451e	845524a5-2d8d-47e0-a279-476df7c604c7	history.create	EmploymentHistory	bc5373d9-457d-4da7-8e2c-04967afec9f4	\N	{"employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:05:48.443
a7d5c020-5af1-4203-bfbc-cfecc0543ec1	845524a5-2d8d-47e0-a279-476df7c604c7	emergency.create	EmergencyContact	7ae6aada-7e86-416c-abd1-f7ee7ac18172	\N	{"employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:06:07.334
0cb2930a-79a9-43ad-9a2b-d2dcf4243f36	845524a5-2d8d-47e0-a279-476df7c604c7	document.upload	Document	66245a4e-ec2d-4adb-9427-9c34abaa0157	\N	{"filename": "Screenshot (1).png", "employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925", "documentType": "degree"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:36:43.327
02c4765d-67db-44ad-9f1e-ccb629af081b	845524a5-2d8d-47e0-a279-476df7c604c7	document.upload	Document	5982a2f5-99c4-4a55-aafb-0d13621d9fc3	\N	{"filename": "Screenshot (58).png", "employeeId": "3e5f19f0-472b-43af-8d2e-95dad613f925", "documentType": "diploma"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 17:39:15.53
c2bc913d-d403-4814-ba81-4c492ea7ea07	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:11:29.79
9aca2669-5c96-4eb5-88e7-6323c05829be	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:11:44.614
f755b31b-07aa-479f-88af-b38400d9a93b	845524a5-2d8d-47e0-a279-476df7c604c7	employee.photo.upload	Employee	3e5f19f0-472b-43af-8d2e-95dad613f925	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:12:30.52
8c1a6923-2372-4540-83a4-15b3add6d6bf	845524a5-2d8d-47e0-a279-476df7c604c7	course.create	Course	b5dd1601-82b9-4b75-bf5a-26e32a947822	\N	{"code": "EWGE667"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:39:00.664
a5de77ef-3177-42a1-8682-453a0be106c0	845524a5-2d8d-47e0-a279-476df7c604c7	section.create	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:39:29.89
09efee63-e18e-402e-b090-24ee30b4f6b5	845524a5-2d8d-47e0-a279-476df7c604c7	user.create	User	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	\N	{"email": "kenaket@gmail.com", "roles": ["af6dc109-7d93-42cc-81e7-a97811afba58"]}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:40:55.147
ef537670-91eb-4cdf-8fdc-e47a904b6e82	845524a5-2d8d-47e0-a279-476df7c604c7	section.assign-instructor	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"instructorId": "5195e4d6-af21-4d28-a2a7-ee031cb8e6f7"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:41:38.013
0fc347e1-8b7e-4a4c-acbf-b85e605f445a	845524a5-2d8d-47e0-a279-476df7c604c7	student.create	Student	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	\N	{"name": "Meseret Angesha", "studentNumber": "DBPC-STU-2026-00001"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:43:23.483
de7b5949-8dcb-4a1c-b71f-ed7f3c1915da	845524a5-2d8d-47e0-a279-476df7c604c7	enrollment.create	Enrollment	f0897cda-a844-4ef5-b498-98020222bb46	\N	{"sectionId": "f69f8065-86c2-406e-8841-a2c12d5bd501", "studentId": "8bfacc90-3a32-4934-b34d-cb3bb135b8cc"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:43:44.607
a16db550-9264-4d19-aa0a-1a51f53516cc	845524a5-2d8d-47e0-a279-476df7c604c7	grades.save-draft	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"entries": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 20:59:37.803
3600a84b-1bde-4200-bde2-88069ca26848	845524a5-2d8d-47e0-a279-476df7c604c7	grades.save-draft	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"entries": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:00:30.33
bbd42ddf-5adb-4f2e-92ec-b245552bf0d6	845524a5-2d8d-47e0-a279-476df7c604c7	grade-component.update	GradeComponent	25757eea-b3aa-448c-949b-9048746f487f	{"id": "25757eea-b3aa-448c-949b-9048746f487f", "name": "Quiz", "isActive": true, "maxScore": 100, "sequence": 1, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T20:36:29.157Z", "updatedBy": null, "departmentId": null, "weightPercent": 10}	{"id": "25757eea-b3aa-448c-949b-9048746f487f", "name": "Quiz", "isActive": true, "maxScore": 10, "sequence": 1, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T21:38:53.517Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "departmentId": null, "weightPercent": 10}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:38:54.294
c1ac8526-d6e0-414e-8e41-4eba893e6db5	845524a5-2d8d-47e0-a279-476df7c604c7	grade-component.update	GradeComponent	5530686e-a56e-40bf-9276-1f3c6b1d472a	{"id": "5530686e-a56e-40bf-9276-1f3c6b1d472a", "name": "Assignment", "isActive": true, "maxScore": 100, "sequence": 2, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T20:36:29.157Z", "updatedBy": null, "departmentId": null, "weightPercent": 15}	{"id": "5530686e-a56e-40bf-9276-1f3c6b1d472a", "name": "Assignment", "isActive": true, "maxScore": 15, "sequence": 2, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T21:39:11.113Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "departmentId": null, "weightPercent": 15}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:39:11.167
a0d1ff2b-054c-45df-8663-6db4e0b25205	845524a5-2d8d-47e0-a279-476df7c604c7	grade-component.update	GradeComponent	8ee4f527-fc85-4c10-afdc-d5bde123d608	{"id": "8ee4f527-fc85-4c10-afdc-d5bde123d608", "name": "Mid Exam", "isActive": true, "maxScore": 100, "sequence": 3, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T20:36:29.157Z", "updatedBy": null, "departmentId": null, "weightPercent": 25}	{"id": "8ee4f527-fc85-4c10-afdc-d5bde123d608", "name": "Mid Exam", "isActive": true, "maxScore": 25, "sequence": 3, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T21:39:19.204Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "departmentId": null, "weightPercent": 25}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:39:19.275
a35d2a8f-edbe-444e-bbc4-d3638b89b33a	845524a5-2d8d-47e0-a279-476df7c604c7	grade-component.update	GradeComponent	192b5c9f-a5d6-4959-b364-85941fb9791b	{"id": "192b5c9f-a5d6-4959-b364-85941fb9791b", "name": "Final Exam", "isActive": true, "maxScore": 100, "sequence": 4, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T20:36:29.157Z", "updatedBy": null, "departmentId": null, "weightPercent": 50}	{"id": "192b5c9f-a5d6-4959-b364-85941fb9791b", "name": "Final Exam", "isActive": true, "maxScore": 50, "sequence": 4, "createdAt": "2026-08-08T20:36:29.157Z", "createdBy": null, "deletedAt": null, "updatedAt": "2026-08-08T21:39:33.620Z", "updatedBy": "845524a5-2d8d-47e0-a279-476df7c604c7", "departmentId": null, "weightPercent": 50}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:39:33.684
61656611-2293-4d92-81f0-e36d4f569440	845524a5-2d8d-47e0-a279-476df7c604c7	grades.save-draft	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"entries": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:40:27.072
6e1d4697-1ca8-4e7b-a4bf-143682ece156	845524a5-2d8d-47e0-a279-476df7c604c7	grades.save-draft	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"entries": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:40:33.666
ac92989c-7ff5-4f4d-9418-4cc2b9a21ced	845524a5-2d8d-47e0-a279-476df7c604c7	grades.save-draft	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"entries": 4}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:40:35.503
0319d8c8-09df-4423-ae0e-649e4be3b895	845524a5-2d8d-47e0-a279-476df7c604c7	grades.submit	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:40:52.922
1428aaeb-cd6f-4d11-a380-0db1b5264c2e	845524a5-2d8d-47e0-a279-476df7c604c7	grades.approve	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:40:59.192
1d089de5-1d85-4c6e-be5f-89ad666eb9af	845524a5-2d8d-47e0-a279-476df7c604c7	grades.publish	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"published": 1}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:42:10.372
a05d1f61-59da-4b8f-a8c4-a70b0dd9876d	845524a5-2d8d-47e0-a279-476df7c604c7	grades.unlock	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:42:15.066
085eb079-d687-445c-bb66-e47a8ebf093b	845524a5-2d8d-47e0-a279-476df7c604c7	grades.submit	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:42:17.426
382483ce-c3a3-4fb2-bec5-5a868a750d6f	845524a5-2d8d-47e0-a279-476df7c604c7	grades.approve	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:42:31.48
0515bc24-36b0-4288-a52c-0002f8085768	845524a5-2d8d-47e0-a279-476df7c604c7	grades.publish	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"published": 1}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 21:42:34.152
4a6441cd-d5c8-4dbd-b9ec-e0f50601c302	845524a5-2d8d-47e0-a279-476df7c604c7	user.reset-password	User	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:10:48.104
a7afb3ea-c760-4acb-8c75-f190a3936045	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:10:54.543
96ab70cc-c7ae-4c7b-9fcd-0c9979307fd4	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.login.failed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:11:14.965
be8d1fcb-9c3e-4f4a-91ac-3d77a3c901df	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.login.failed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:11:41.649
65f2b588-2e31-4f65-bb07-af25ce2bd230	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:11:54.391
9578c672-eec0-474c-8ccc-720879c9ad95	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.password.changed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:12:35.219
ae51f363-59d8-4050-90da-53feb5460138	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:12:35.305
d3ee6762-9fc1-4c3e-a130-600119824eba	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:13:00.724
59199e17-327a-49b0-b51a-441bb15fba5a	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:32:29.164
55b6572b-4150-4417-876e-c618d9d21ff8	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:32:44.96
52495cf0-f095-46dd-86ed-b92d02ed6a21	845524a5-2d8d-47e0-a279-476df7c604c7	grades.unlock	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:32:59.611
48f092a9-c010-4050-a337-67a0b50a7190	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:33:20.182
78f0b6bf-eca7-4b14-9f33-fbccd6b58685	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:33:27.966
565afbaf-cf40-4b72-8a03-d519e5d7ae1e	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	grades.submit	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:33:40.773
a5b63dfd-b85a-4b33-9400-7c1c4d20b523	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:33:53.998
29b4150a-dd5c-4c86-9926-7e75983e7ecc	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:34:08.683
afc70106-0c22-4467-a25f-efa3fea7349d	845524a5-2d8d-47e0-a279-476df7c604c7	grades.approve	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:34:59.376
2827ba48-4b5b-43ec-8630-c7e85dcfff91	845524a5-2d8d-47e0-a279-476df7c604c7	grades.publish	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"published": 1}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:35:05.013
7547d51d-48f0-4076-bac2-783bd55da58e	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:35:10.717
58fb3327-6f38-4436-b2ba-e1d9622571ca	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:56:29.694
779f8d16-29c3-4f55-b063-7b0b752b7d30	845524a5-2d8d-47e0-a279-476df7c604c7	grades.unlock	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:57:56.29
0559d4ee-929a-4589-a5e8-620c1c6700fd	845524a5-2d8d-47e0-a279-476df7c604c7	grades.submit	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:57:57.688
c08de92a-f465-4bfe-8534-b750fcb756dd	845524a5-2d8d-47e0-a279-476df7c604c7	grades.approve	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:57:59.097
ac6b218b-6d89-4035-a3f9-0de64657aa30	845524a5-2d8d-47e0-a279-476df7c604c7	grades.publish	Section	f69f8065-86c2-406e-8841-a2c12d5bd501	\N	{"published": 1}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:58:03.409
b745a5ee-5f2f-4064-bd6d-afe14dc5bfc6	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:03:25.768
83841bad-24b7-41c0-b563-869fdcb83b19	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:03:36.774
3254ff78-9467-4af0-b31b-050dc5194ee6	845524a5-2d8d-47e0-a279-476df7c604c7	user.create	User	e9b42419-ded4-4ec3-8a18-1606a758ced4	\N	{"email": "registrar@gmail.com", "roles": ["deab7ba7-051f-4b69-9751-60826cdb0235"]}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:04:40.299
3b97fc01-c75d-42b2-8520-16f3e35b6667	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:04:51.687
620ef9c4-82bf-46a7-b85e-b3a4f2a1bc58	e9b42419-ded4-4ec3-8a18-1606a758ced4	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:05:23.16
6120faba-93d9-447e-8f7a-7a57db63d282	e9b42419-ded4-4ec3-8a18-1606a758ced4	auth.password.changed	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:06:01.483
702f1653-090d-4f96-9e88-29d2883513ab	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:06:01.536
18cfeb26-1ad8-40e3-9672-c09d96bdab6f	e9b42419-ded4-4ec3-8a18-1606a758ced4	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:06:14.856
c782b50e-5367-4722-940c-b737fe3ac3e0	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:11:00.29
258e2ed2-94c3-4857-ae84-ec133553ac1c	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:11:08.575
95ae340a-ac0b-428c-acc1-f6ebf0d22ce2	845524a5-2d8d-47e0-a279-476df7c604c7	student.photo.upload	Student	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:25:38.627
25a4ee3b-e4c4-435f-8888-41972863d538	845524a5-2d8d-47e0-a279-476df7c604c7	student.update	Student	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	{"status": "active"}	{"status": "active"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:25:44.078
dfdc27e7-14fc-4d78-b09c-5e05de5e71a4	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:55:59.228
1a00f683-93f5-46b8-8d2e-2f4a06ec06e7	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:56:12.258
9ad00d64-5aaa-47d6-a079-4e3724ad8128	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 00:29:41.504
65c0f531-8185-4296-99df-db685ef42c55	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 00:30:19.371
012de29a-580a-4f2c-8a28-2ab4c563a93c	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:01.563
f96f45c4-f232-40e3-ae8c-eab7aa04dab1	e9b42419-ded4-4ec3-8a18-1606a758ced4	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:12.423
9713a4d2-b04c-4fc3-892d-f03fb655338a	\N	auth.logout	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:26.776
2282a5f5-15a3-40a2-86f5-9cf5d8369acd	845524a5-2d8d-47e0-a279-476df7c604c7	auth.login.success	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:36.281
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courses (id, program_id, code, title, credit_hours, category, is_active, created_at, updated_at, created_by, updated_by, deleted_at, version) FROM stdin;
b5dd1601-82b9-4b75-bf5a-26e32a947822	\N	EWGE667	sguwe wbvwewn	10	gyehewq	t	2026-08-08 19:39:00.621	2026-08-08 19:39:00.621	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, name, code, description, is_active, created_at, updated_at, created_by, updated_by, deleted_at, version, head_user_id) FROM stdin;
a93a3405-de29-41f7-ae4e-860536f98366	Beket Mitiku Amenu	BMD	\N	t	2026-08-08 15:15:27.509	2026-08-08 15:15:43.048	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 15:15:43.047	0	\N
6a6a99a5-0dd3-4180-9bd9-5fe5aef14dbf	Beket Mitiku	BM	\N	t	2026-08-08 15:14:56.099	2026-08-08 15:16:11.009	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 15:16:11.008	0	\N
520548b2-a7cc-49ef-a8dd-72bc632f7733	Farming	FM	\N	t	2026-08-08 16:30:20.575	2026-08-08 16:35:06.319	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	1	\N
a104db70-d76b-4061-9f72-51d2d574605b	Python Engineering	PE	\N	f	2026-08-08 15:37:47.419	2026-08-08 16:35:14.905	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	1	\N
\.


--
-- Data for Name: document_verifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_verifications (id, code, document_kind, subject_type, subject_id, subject_label, issued_by, revoked_at, created_at) FROM stdin;
aefaf1c0-28fc-43a9-a0ce-6f0377f4ec14	BP33-2K7N-KCRP	employee_profile	employee	3e5f19f0-472b-43af-8d2e-95dad613f925	Beket Mitiku Amenu (DBPC-EMP-2026-00001)	845524a5-2d8d-47e0-a279-476df7c604c7	\N	2026-08-08 18:24:53.589
63b85b57-8769-4a88-9bf8-b853b14be476	6JGD-BLMQ-ZDW5	employee_profile	employee	3e5f19f0-472b-43af-8d2e-95dad613f925	Beket Mitiku Amenu (DBPC-EMP-2026-00001)	845524a5-2d8d-47e0-a279-476df7c604c7	\N	2026-08-08 18:50:38.301
ffcd88f2-6285-4d75-b335-cbd62e6f218c	WGDB-TATJ-53VP	employee_profile	employee	3e5f19f0-472b-43af-8d2e-95dad613f925	Beket Mitiku Amenu (DBPC-EMP-2026-00001)	845524a5-2d8d-47e0-a279-476df7c604c7	\N	2026-08-08 19:12:36.909
13686e62-a886-49a4-9dcd-e80abdced749	6AKH-G3XX-R68N	transcript	student	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	Meseret Irko Angesha (DBPC-STU-2026-00001)	845524a5-2d8d-47e0-a279-476df7c604c7	\N	2026-08-08 23:24:05.182
b96d17e3-6c71-4351-ae57-822671c64f4c	RT6U-FLVS-8758	transcript	student	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	Meseret Irko Angesha (DBPC-STU-2026-00001)	845524a5-2d8d-47e0-a279-476df7c604c7	\N	2026-08-09 00:31:02.429
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, owner_type, owner_id, document_type, original_filename, storage_key, mime_type, size_bytes, checksum, uploaded_by, created_at, deleted_at) FROM stdin;
66245a4e-ec2d-4adb-9427-9c34abaa0157	employee	3e5f19f0-472b-43af-8d2e-95dad613f925	degree	Screenshot (1).png	employees/3e5f19f0-472b-43af-8d2e-95dad613f925/6dee1acf-79ae-4795-80a1-6e3511f72857.jpg	image/jpeg	107832	b3ca4d84501d330a4753e9a18abec8d521316f39beb958494f5e84c50ef170f5	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 17:36:43.297	\N
5982a2f5-99c4-4a55-aafb-0d13621d9fc3	employee	3e5f19f0-472b-43af-8d2e-95dad613f925	diploma	Screenshot (58).png	employees/3e5f19f0-472b-43af-8d2e-95dad613f925/dd2d285c-19c5-47a0-8824-a23c1dfff020.jpg	image/jpeg	59062	dd2b7754f591593e60b1b26478c25b68f8e17577f9a48bbb2987d11ce9ce96d3	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 17:39:14.873	\N
\.


--
-- Data for Name: emergency_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.emergency_contacts (id, employee_id, name, relationship, phone_number, address, created_at, updated_at) FROM stdin;
7ae6aada-7e86-416c-abd1-f7ee7ac18172	3e5f19f0-472b-43af-8d2e-95dad613f925	Beket Mitiku Amenu	etytjkhbhj	0945105592	DembiDollo	2026-08-08 17:06:07.082	2026-08-08 17:06:07.082
\.


--
-- Data for Name: employee_education; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_education (id, employee_id, institution, qualification, field_of_study, graduation_year, gpa, created_at, updated_at) FROM stdin;
00fd2505-66f5-499c-b017-b8a7a172a3a0	3e5f19f0-472b-43af-8d2e-95dad613f925	NGSSS	Degree	Agriculture	2009	3.6	2026-08-08 17:03:56.664	2026-08-08 17:03:56.664
f887af24-c200-4c0d-86af-4295351d455c	3e5f19f0-472b-43af-8d2e-95dad613f925	NGSSS	Degree	Agriculture	2012	3.6	2026-08-08 17:04:19.89	2026-08-08 17:04:19.89
\.


--
-- Data for Name: employee_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_number_sequences (year, last_value) FROM stdin;
2026	1
\.


--
-- Data for Name: employee_qualifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_qualifications (id, employee_id, type, title, issuer, issue_date, expiry_date, reference_no, created_at, updated_at) FROM stdin;
4dfa9fcf-3304-4111-98c8-9db1a0f22535	3e5f19f0-472b-43af-8d2e-95dad613f925	license	0987654321	vtgiukjn jn	2024-05-06	2026-08-28	poiuytrfg77u099	2026-08-08 17:05:03.097	2026-08-08 17:05:03.097
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, employee_number, first_name, middle_name, last_name, gender, date_of_birth, nationality, marital_status, national_id, tax_id, phone_number, email, address, department_id, "position", employment_type, contract_type, employment_status, date_of_employment, contract_end_date, salary_grade, office_location, supervisor_id, created_at, updated_at, created_by, updated_by, deleted_at, version, photo_storage_key) FROM stdin;
3e5f19f0-472b-43af-8d2e-95dad613f925	DBPC-EMP-2026-00001	Beket	Mitiku	Amenu	male	2017-01-18	Ethiopian	single	09876543210987654321	uhv67e98y3ujg36r	0945105592	bekera@gmail.com	DembiDollo	520548b2-a7cc-49ef-a8dd-72bc632f7733	Ethiopian	full_time	optional	active	2027-10-23	2029-05-16	high	Dembi Dollo	\N	2026-08-08 16:46:28.616	2026-08-08 19:12:30.476	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0	employees/3e5f19f0-472b-43af-8d2e-95dad613f925/photo/05184674-49e1-4f5e-9ea1-c739cb7377cc.jpg
\.


--
-- Data for Name: employment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employment_history (id, employee_id, employer, "position", start_date, end_date, responsibilities, created_at, updated_at) FROM stdin;
bc5373d9-457d-4da7-8e2c-04967afec9f4	3e5f19f0-472b-43af-8d2e-95dad613f925	09876587yiuhjb	tuioiuiou	2026-07-08	2023-06-03	yhjkhkjhfgkjlk	2026-08-08 17:05:48.256	2026-08-08 17:05:48.256
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enrollments (id, student_id, section_id, status, attempt_number, created_at, updated_at, created_by, deleted_at) FROM stdin;
f0897cda-a844-4ef5-b498-98020222bb46	8bfacc90-3a32-4934-b34d-cb3bb135b8cc	f69f8065-86c2-406e-8841-a2c12d5bd501	completed	1	2026-08-08 19:43:44.563	2026-08-08 22:58:02.025	845524a5-2d8d-47e0-a279-476df7c604c7	\N
\.


--
-- Data for Name: grade_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grade_components (id, name, weight_percent, sequence, department_id, is_active, created_at, updated_at, created_by, updated_by, deleted_at, max_score) FROM stdin;
25757eea-b3aa-448c-949b-9048746f487f	Quiz	10	1	\N	t	2026-08-08 20:36:29.157	2026-08-08 21:38:53.517	\N	845524a5-2d8d-47e0-a279-476df7c604c7	\N	10
5530686e-a56e-40bf-9276-1f3c6b1d472a	Assignment	15	2	\N	t	2026-08-08 20:36:29.157	2026-08-08 21:39:11.113	\N	845524a5-2d8d-47e0-a279-476df7c604c7	\N	15
8ee4f527-fc85-4c10-afdc-d5bde123d608	Mid Exam	25	3	\N	t	2026-08-08 20:36:29.157	2026-08-08 21:39:19.204	\N	845524a5-2d8d-47e0-a279-476df7c604c7	\N	25
192b5c9f-a5d6-4959-b364-85941fb9791b	Final Exam	50	4	\N	t	2026-08-08 20:36:29.157	2026-08-08 21:39:33.62	\N	845524a5-2d8d-47e0-a279-476df7c604c7	\N	50
\.


--
-- Data for Name: grade_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grade_entries (id, enrollment_id, component_id, score, max_score, entered_by, created_at, updated_at) FROM stdin;
93a7971c-086e-4d72-ad31-1f9e1cd6686d	f0897cda-a844-4ef5-b498-98020222bb46	25757eea-b3aa-448c-949b-9048746f487f	10	10	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 20:59:37.715	2026-08-08 21:40:35.465
f8114e1d-1b6a-4117-b2c9-9ac71f546812	f0897cda-a844-4ef5-b498-98020222bb46	5530686e-a56e-40bf-9276-1f3c6b1d472a	14	15	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 20:59:37.719	2026-08-08 21:40:35.466
b0672ceb-1c9c-4a2b-b033-f67a00bcc39f	f0897cda-a844-4ef5-b498-98020222bb46	8ee4f527-fc85-4c10-afdc-d5bde123d608	22	25	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 20:59:37.721	2026-08-08 21:40:35.468
93d9bbdf-bb8f-4780-b024-c0434fdee386	f0897cda-a844-4ef5-b498-98020222bb46	192b5c9f-a5d6-4959-b364-85941fb9791b	48	50	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 20:59:37.724	2026-08-08 21:40:35.47
\.


--
-- Data for Name: grade_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grade_results (id, enrollment_id, percentage, letter, grade_point, is_pass, applied_snapshot, published_at, created_at, updated_at) FROM stdin;
4357222d-4990-450e-b9e5-0b6dea9f2039	f0897cda-a844-4ef5-b498-98020222bb46	94	A+	4	t	{"bands": [{"isPass": true, "letter": "A+", "gradePoint": 4, "maxPercent": 100, "minPercent": 90}, {"isPass": true, "letter": "A", "gradePoint": 4, "maxPercent": 89, "minPercent": 85}, {"isPass": true, "letter": "A-", "gradePoint": 3.75, "maxPercent": 84, "minPercent": 80}, {"isPass": true, "letter": "B+", "gradePoint": 3.5, "maxPercent": 79, "minPercent": 75}, {"isPass": true, "letter": "B", "gradePoint": 3, "maxPercent": 74, "minPercent": 70}, {"isPass": true, "letter": "B-", "gradePoint": 2.75, "maxPercent": 69, "minPercent": 65}, {"isPass": true, "letter": "C+", "gradePoint": 2.5, "maxPercent": 64, "minPercent": 60}, {"isPass": true, "letter": "C", "gradePoint": 2, "maxPercent": 59, "minPercent": 50}, {"isPass": false, "letter": "D", "gradePoint": 1, "maxPercent": 49, "minPercent": 40}, {"isPass": false, "letter": "F", "gradePoint": 0, "maxPercent": 39, "minPercent": 0}], "passMark": 50, "rounding": "half_up", "scaleName": "Standard 4.0", "components": [{"id": "25757eea-b3aa-448c-949b-9048746f487f", "name": "Quiz", "maxScore": 10, "weightPercent": 10}, {"id": "5530686e-a56e-40bf-9276-1f3c6b1d472a", "name": "Assignment", "maxScore": 15, "weightPercent": 15}, {"id": "8ee4f527-fc85-4c10-afdc-d5bde123d608", "name": "Mid Exam", "maxScore": 25, "weightPercent": 25}, {"id": "192b5c9f-a5d6-4959-b364-85941fb9791b", "name": "Final Exam", "maxScore": 50, "weightPercent": 50}], "publishedAt": "2026-08-08T22:58:02.016Z"}	2026-08-08 22:58:02.018	2026-08-08 21:42:10.094	2026-08-08 22:58:02.02
\.


--
-- Data for Name: grade_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grade_submissions (id, section_id, status, submitted_by, submitted_at, approved_by, approved_at, published_by, published_at, locked_at, returned_by, return_reason, created_at, updated_at) FROM stdin;
c62f0ea4-03c1-4313-9975-86aa6f1a6d95	f69f8065-86c2-406e-8841-a2c12d5bd501	published	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 22:57:57.65	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 22:57:59.064	845524a5-2d8d-47e0-a279-476df7c604c7	2026-08-08 22:58:02.027	2026-08-08 22:58:02.027	\N	\N	2026-08-08 20:59:37.725	2026-08-08 22:58:02.028
\.


--
-- Data for Name: grading_scale_bands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grading_scale_bands (id, scale_id, min_percent, max_percent, letter, grade_point, is_pass) FROM stdin;
35acb17b-4ad1-4c1e-9578-a8f9e779b77c	29ac652d-c070-4328-a17e-e47dc2f6eabd	90	100	A+	4	t
9d81779e-d2bc-4a8c-9620-352fd70a5f84	29ac652d-c070-4328-a17e-e47dc2f6eabd	85	89	A	4	t
7af29156-2d2e-4cd7-a718-22f4b4acf76f	29ac652d-c070-4328-a17e-e47dc2f6eabd	80	84	A-	3.75	t
026973e2-eb58-44b8-9f09-c5dd0f17dc0c	29ac652d-c070-4328-a17e-e47dc2f6eabd	75	79	B+	3.5	t
85d81f45-c27e-49c1-bea1-8930706faa16	29ac652d-c070-4328-a17e-e47dc2f6eabd	70	74	B	3	t
39887224-c625-460c-a14b-7ccdc838f446	29ac652d-c070-4328-a17e-e47dc2f6eabd	65	69	B-	2.75	t
2c22af05-d035-4858-a1f7-897556c36a7c	29ac652d-c070-4328-a17e-e47dc2f6eabd	60	64	C+	2.5	t
17a97972-be51-4fa8-a204-fa6e29ebb310	29ac652d-c070-4328-a17e-e47dc2f6eabd	50	59	C	2	t
407fa6e9-f12a-469a-891d-b0f270c489c9	29ac652d-c070-4328-a17e-e47dc2f6eabd	40	49	D	1	f
b5e72a77-62be-468a-a65a-4828f89f8373	29ac652d-c070-4328-a17e-e47dc2f6eabd	0	39	F	0	f
\.


--
-- Data for Name: grading_scales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grading_scales (id, name, department_id, version, is_active, pass_mark, rounding, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
29ac652d-c070-4328-a17e-e47dc2f6eabd	Standard 4.0	\N	1	t	50	half_up	2026-08-08 20:36:29.046	2026-08-08 20:36:29.046	\N	\N	\N
\.


--
-- Data for Name: instructor_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instructor_assignments (id, section_id, instructor_id, assigned_at, assigned_by) FROM stdin;
0d47f68d-148a-4106-a23f-b2e2aa3d009c	f69f8065-86c2-406e-8841-a2c12d5bd501	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	2026-08-08 19:41:37.674	845524a5-2d8d-47e0-a279-476df7c604c7
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, key, description, created_at) FROM stdin;
784cf8e6-6484-48d0-bd20-0ce0218e7843	user:read	\N	2026-08-08 14:16:02.443
fa210db4-bdca-40be-83b5-05e88f25c983	user:create	\N	2026-08-08 14:16:02.537
f32fd466-8a76-4b40-9340-a0933cb77eae	user:update	\N	2026-08-08 14:16:02.575
6af641c3-fa88-4105-9134-1eed49872f95	user:delete	\N	2026-08-08 14:16:02.614
09af06ae-c8f1-4542-bb8a-57ae5ca9251b	user:reset-password	\N	2026-08-08 14:16:02.653
6935d4d8-8ec4-42ca-b0e8-07730a1132ad	role:read	\N	2026-08-08 14:16:02.692
9ce1e579-a23d-44cc-a62a-d4e5b3849765	role:manage	\N	2026-08-08 14:16:02.753
ffb33565-7167-4a4c-8265-db53a20e27a6	department:read	\N	2026-08-08 14:16:02.791
5eda22d7-e3db-40af-b4ab-07f7e86bdb8d	department:manage	\N	2026-08-08 14:16:02.83
dbd3fad8-bca9-4b97-89de-7f78ebdf9276	program:read	\N	2026-08-08 14:16:02.869
11985807-994a-4a49-8af9-c00f6c219ca2	program:manage	\N	2026-08-08 14:16:02.919
a66a3e4b-3c74-4b15-8a48-536b9f4ea6a3	academic-year:manage	\N	2026-08-08 14:16:02.979
c2e7982a-55b8-4341-91ad-93ffed3fa8d6	semester:manage	\N	2026-08-08 14:16:03.115
cfbb1614-1da5-44f7-8822-e5245ac8f1f2	course:manage	\N	2026-08-08 14:16:03.243
d0e1ae95-e48c-4198-ba63-1e3797393834	section:manage	\N	2026-08-08 14:16:03.271
b331cb8b-7571-4448-8997-f554cf28a071	employee:read	\N	2026-08-08 14:16:03.299
e959ae5d-3fd0-4fec-837d-6bddd5f219d9	employee:create	\N	2026-08-08 14:16:03.337
34187f8b-973b-495c-a80c-35c21b648c8c	employee:update	\N	2026-08-08 14:16:03.377
0dd8135f-fc96-42e7-8233-57669be823d1	employee:delete	\N	2026-08-08 14:16:03.462
0f581cdb-dbb0-4b2b-9408-0327761ef48f	employee:print	\N	2026-08-08 14:16:03.518
606e75d1-9f5e-4b19-84a9-d2db6c579de0	document:upload	\N	2026-08-08 14:16:03.579
cd1adcb4-1282-4a9e-9399-5547d1a61115	document:read	\N	2026-08-08 14:16:03.644
f7b2071c-705a-41f5-80c5-5d2d4bbce218	document:delete	\N	2026-08-08 14:16:03.695
63677a90-addf-4dbd-af43-a8aad6189fd1	student:read	\N	2026-08-08 14:16:03.747
cfa0ba1f-835a-4bb4-bab6-a19233649d55	student:manage	\N	2026-08-08 14:16:03.786
578b0ffe-0181-4c17-b1d6-4b26bafe6182	grade:enter	\N	2026-08-08 14:16:03.814
9ad50c17-52a8-49d5-bfe9-09985d91c276	grade:submit	\N	2026-08-08 14:16:03.852
209c4c85-8ad8-4f48-a127-1fe037eb32d1	grade:approve	\N	2026-08-08 14:16:03.88
dbcca4a7-95ac-4586-8ee4-c818d71ad702	grade:publish	\N	2026-08-08 14:16:03.92
ca7c741d-b50a-4e45-a11e-d57665b62e60	grade:unlock	\N	2026-08-08 14:16:03.947
7fc4814e-5acf-4fe2-ac5c-306ddd636d51	grading:config	\N	2026-08-08 14:16:03.986
c6d58031-8ace-400d-ae2b-17e34e4ad6da	report:view	\N	2026-08-08 14:16:04.014
341a7730-88f0-472a-a4b2-8331b27a2cae	analytics:view	\N	2026-08-08 14:16:04.053
d8887a80-8c38-46d1-9cce-c475747e0df9	audit-log:read	\N	2026-08-08 14:16:04.091
12414599-32e8-424b-828a-a2f02a54ce6e	system-setting:manage	\N	2026-08-08 14:16:04.13
8a2ee480-dd13-46b4-96f6-98c6077cc5df	own-profile:read	\N	2026-08-08 14:16:04.169
7b5859e5-0b3e-4381-aa2e-fe9eb6643593	own-profile:update-limited	\N	2026-08-08 14:16:04.208
70441a44-a680-4b72-9697-710b50f117c5	transcript:generate	\N	2026-08-08 23:23:00.279
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programs (id, department_id, name, code, degree_level, duration_years, is_active, created_at, updated_at, created_by, updated_by, deleted_at, version) FROM stdin;
18804f06-c453-4a08-af69-8888fb80b8f5	a104db70-d76b-4061-9f72-51d2d574605b	DEpartment head	BETT	Degree	4	t	2026-08-08 15:38:43.463	2026-08-08 15:38:43.463	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, revoked_at, ip_address, user_agent, created_at) FROM stdin;
fa530453-1acb-4622-b859-22c58a406285	845524a5-2d8d-47e0-a279-476df7c604c7	75a6e8091c0a0182a5e97f940078771af2d21af7fc81116dd465fcf9dabe9eab	2026-08-15 14:19:22.721	2026-08-08 14:20:19.416	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:19:22.722
ab349ce1-2897-4639-94f0-f02e14161421	845524a5-2d8d-47e0-a279-476df7c604c7	2df74789f797a635b39061c1e089ed8d949b91ba60207a9e87a67f8308f3699c	2026-08-15 14:21:11.21	2026-08-08 14:24:15.826	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:21:11.212
48f74c0a-ae33-40c5-8aee-4d8c3ef9fee7	845524a5-2d8d-47e0-a279-476df7c604c7	9c704b3d132d1e0d8bdba5c182c5e92fddeeecc1c5505a8c9ef087c6fdb8c9bb	2026-08-15 14:43:54.287	2026-08-08 16:01:51.954	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 14:43:54.338
db480bd8-044c-469b-ab09-a12e9d19c031	845524a5-2d8d-47e0-a279-476df7c604c7	7ec5c4f8063ef2e9b7ee6bfec3ba5bbf290c1cf5284f5c3a7e9b6a288b8e1552	2026-08-15 16:26:10.989	2026-08-08 16:27:10.422	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:26:10.991
3cb53cf1-0ebb-4e10-a34e-f932339f8691	845524a5-2d8d-47e0-a279-476df7c604c7	1b5f6eaf4b5e15e04ca0bf802230ee64767c390299159285f522db6f17ad1e32	2026-08-15 16:27:26.432	2026-08-08 16:29:32.993	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:27:26.434
c4ec720c-6fd0-476b-8752-aebfe60a7d0d	845524a5-2d8d-47e0-a279-476df7c604c7	c439bdf5d0c2c39795c98353cfc2bea0beb82b38de1e78e943b568811ee17017	2026-08-15 16:29:59.204	2026-08-08 16:36:21.099	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:29:59.205
9d957bdf-641f-4774-a0da-2478b07d1fee	845524a5-2d8d-47e0-a279-476df7c604c7	6726b5ea1eb2273b4a163a28be43edddd10c2020ebe48548fd39a89f9c3f0efd	2026-08-15 16:44:41.432	2026-08-08 19:11:29.683	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 16:44:41.433
0e8bf6c2-e5de-4a94-8f70-08ad3fe493fd	845524a5-2d8d-47e0-a279-476df7c604c7	fc1f331cf0df8fca39db1165da95ab6566cc150a3d4b1652cd17e214fbd95c24	2026-08-15 19:11:44.552	2026-08-08 22:10:54.467	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 19:11:44.553
c9c90bc5-097c-4300-85bc-e82bbaa0f04c	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	7bdb9086b01673f3e9699f7bbcfbae0cba42695d363496cc785b326cbde941c3	2026-08-15 22:11:54.355	2026-08-08 22:12:35.156	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:11:54.356
10c02169-50ca-413d-bfbf-0bc50b828523	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	0d677e1e5e0c0773caca2d88f9b82a34ab9a221d0d15ee67fd202b0c793e6cf1	2026-08-15 22:13:00.685	2026-08-08 22:32:28.358	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:13:00.686
4e5a9fb8-d252-4251-860d-30092616a190	845524a5-2d8d-47e0-a279-476df7c604c7	e98ca867ca45a44a5df8483fd8d73f54d91378727c50a2584bd0e48e628ddcb0	2026-08-15 22:32:44.921	2026-08-08 22:33:19.77	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:32:44.922
5d53d85b-6c7a-4048-ac3c-877274c885b4	5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	20da070cc4e57c69e8eef9884aa4d73152c61afd14c6be7ee35d6ccde63bf5ac	2026-08-15 22:33:27.929	2026-08-08 22:33:53.956	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:33:27.931
c4e51f55-0289-4e61-9420-224cefa06d1b	845524a5-2d8d-47e0-a279-476df7c604c7	43700260be52e8063e27ddf356f62b7d9c9d06a89d33b423616d7c72ecfe0309	2026-08-15 22:34:08.645	2026-08-08 22:35:10.283	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:34:08.646
0b4d6f7f-2a8c-4246-838d-0c2b36ce3fea	845524a5-2d8d-47e0-a279-476df7c604c7	7218f8fa2ba6f60f09ed4caa225483d3a22f48f2d8028add5fd18646f7998067	2026-08-15 22:56:29.658	2026-08-08 23:03:25.394	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 22:56:29.659
70455cc4-536f-4f1d-a502-84cb166e9cca	845524a5-2d8d-47e0-a279-476df7c604c7	e549f4261fc76fac1133958363dfb64fa4f14ba09aa270c5b33d43ae4c049570	2026-08-15 23:03:36.726	2026-08-08 23:04:51.579	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:03:36.727
965e422b-d239-48df-8d84-0ca7c97bfe58	e9b42419-ded4-4ec3-8a18-1606a758ced4	cf077bd575fb1378892cfcf917b2afce1368ffcd0c9f0ec08b4518677889f4b0	2026-08-15 23:05:23.088	2026-08-08 23:06:01.447	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:05:23.09
64d43844-f023-475e-9d03-2a762382ab3f	e9b42419-ded4-4ec3-8a18-1606a758ced4	b7db8aad0e9e64ed8614ba9d126f16d25335e9c26bd24075c96c5d97c983bac3	2026-08-15 23:06:14.768	2026-08-08 23:11:00.096	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:06:14.769
a7760dfb-b0e4-4273-8e77-c03a9726423a	845524a5-2d8d-47e0-a279-476df7c604c7	176deb64eb4e014e1de8062cc0cc4c1d189e489304dae8ae99da390936e08dc3	2026-08-15 23:11:08.546	2026-08-08 23:55:59.175	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:11:08.547
1ebed979-e11c-4140-adcf-1dac0312b3c3	845524a5-2d8d-47e0-a279-476df7c604c7	3616aa26ca486936b86cf949d4d74c26f30ec58afade6a699580d828b58d6683	2026-08-15 23:56:12.22	2026-08-09 00:29:41.328	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-08 23:56:12.222
82eadbab-6b33-467a-ad74-edbdcfe89e04	845524a5-2d8d-47e0-a279-476df7c604c7	3a1d00a08d9a51cf1419a6d1de9ef1e717a8f11f902b00448ff225d28298552c	2026-08-16 00:30:19.289	2026-08-09 01:15:01.515	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 00:30:19.29
7919a731-f643-4be9-85c8-b15c255aa1e3	e9b42419-ded4-4ec3-8a18-1606a758ced4	226157349325026c5da502432dfcbc0ffc22012bf0b8eb9df2a2b0cb81c7a98b	2026-08-16 01:15:12.374	2026-08-09 01:15:26.749	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:12.375
7d3149c9-0e7b-4faa-8777-947fd5677110	845524a5-2d8d-47e0-a279-476df7c604c7	644c90d1bf43fcccb68dc4a8d97a27a2689f9ece09d036d5b49a1043cb4a351d	2026-08-16 01:15:36.242	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-09 01:15:36.243
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	784cf8e6-6484-48d0-bd20-0ce0218e7843
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	fa210db4-bdca-40be-83b5-05e88f25c983
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	f32fd466-8a76-4b40-9340-a0933cb77eae
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	6af641c3-fa88-4105-9134-1eed49872f95
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	09af06ae-c8f1-4542-bb8a-57ae5ca9251b
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	6935d4d8-8ec4-42ca-b0e8-07730a1132ad
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	9ce1e579-a23d-44cc-a62a-d4e5b3849765
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	ffb33565-7167-4a4c-8265-db53a20e27a6
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	5eda22d7-e3db-40af-b4ab-07f7e86bdb8d
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	dbd3fad8-bca9-4b97-89de-7f78ebdf9276
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	11985807-994a-4a49-8af9-c00f6c219ca2
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	a66a3e4b-3c74-4b15-8a48-536b9f4ea6a3
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	c2e7982a-55b8-4341-91ad-93ffed3fa8d6
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	cfbb1614-1da5-44f7-8822-e5245ac8f1f2
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	d0e1ae95-e48c-4198-ba63-1e3797393834
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	b331cb8b-7571-4448-8997-f554cf28a071
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	e959ae5d-3fd0-4fec-837d-6bddd5f219d9
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	34187f8b-973b-495c-a80c-35c21b648c8c
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	0dd8135f-fc96-42e7-8233-57669be823d1
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	0f581cdb-dbb0-4b2b-9408-0327761ef48f
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	606e75d1-9f5e-4b19-84a9-d2db6c579de0
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	cd1adcb4-1282-4a9e-9399-5547d1a61115
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	f7b2071c-705a-41f5-80c5-5d2d4bbce218
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	63677a90-addf-4dbd-af43-a8aad6189fd1
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	cfa0ba1f-835a-4bb4-bab6-a19233649d55
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	578b0ffe-0181-4c17-b1d6-4b26bafe6182
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	9ad50c17-52a8-49d5-bfe9-09985d91c276
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	209c4c85-8ad8-4f48-a127-1fe037eb32d1
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	dbcca4a7-95ac-4586-8ee4-c818d71ad702
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	ca7c741d-b50a-4e45-a11e-d57665b62e60
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	7fc4814e-5acf-4fe2-ac5c-306ddd636d51
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	70441a44-a680-4b72-9697-710b50f117c5
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	c6d58031-8ace-400d-ae2b-17e34e4ad6da
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	341a7730-88f0-472a-a4b2-8331b27a2cae
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	d8887a80-8c38-46d1-9cce-c475747e0df9
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	12414599-32e8-424b-828a-a2f02a54ce6e
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	8a2ee480-dd13-46b4-96f6-98c6077cc5df
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	7b5859e5-0b3e-4381-aa2e-fe9eb6643593
728f14cc-a459-47e9-99d4-d07e12e97a36	b331cb8b-7571-4448-8997-f554cf28a071
728f14cc-a459-47e9-99d4-d07e12e97a36	e959ae5d-3fd0-4fec-837d-6bddd5f219d9
728f14cc-a459-47e9-99d4-d07e12e97a36	34187f8b-973b-495c-a80c-35c21b648c8c
728f14cc-a459-47e9-99d4-d07e12e97a36	0f581cdb-dbb0-4b2b-9408-0327761ef48f
728f14cc-a459-47e9-99d4-d07e12e97a36	606e75d1-9f5e-4b19-84a9-d2db6c579de0
728f14cc-a459-47e9-99d4-d07e12e97a36	cd1adcb4-1282-4a9e-9399-5547d1a61115
728f14cc-a459-47e9-99d4-d07e12e97a36	ffb33565-7167-4a4c-8265-db53a20e27a6
728f14cc-a459-47e9-99d4-d07e12e97a36	c6d58031-8ace-400d-ae2b-17e34e4ad6da
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	b331cb8b-7571-4448-8997-f554cf28a071
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	ffb33565-7167-4a4c-8265-db53a20e27a6
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	dbd3fad8-bca9-4b97-89de-7f78ebdf9276
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	63677a90-addf-4dbd-af43-a8aad6189fd1
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	c6d58031-8ace-400d-ae2b-17e34e4ad6da
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	341a7730-88f0-472a-a4b2-8331b27a2cae
deab7ba7-051f-4b69-9751-60826cdb0235	63677a90-addf-4dbd-af43-a8aad6189fd1
deab7ba7-051f-4b69-9751-60826cdb0235	cfa0ba1f-835a-4bb4-bab6-a19233649d55
deab7ba7-051f-4b69-9751-60826cdb0235	c2e7982a-55b8-4341-91ad-93ffed3fa8d6
deab7ba7-051f-4b69-9751-60826cdb0235	cfbb1614-1da5-44f7-8822-e5245ac8f1f2
deab7ba7-051f-4b69-9751-60826cdb0235	d0e1ae95-e48c-4198-ba63-1e3797393834
deab7ba7-051f-4b69-9751-60826cdb0235	dbcca4a7-95ac-4586-8ee4-c818d71ad702
deab7ba7-051f-4b69-9751-60826cdb0235	ca7c741d-b50a-4e45-a11e-d57665b62e60
deab7ba7-051f-4b69-9751-60826cdb0235	70441a44-a680-4b72-9697-710b50f117c5
deab7ba7-051f-4b69-9751-60826cdb0235	ffb33565-7167-4a4c-8265-db53a20e27a6
deab7ba7-051f-4b69-9751-60826cdb0235	dbd3fad8-bca9-4b97-89de-7f78ebdf9276
deab7ba7-051f-4b69-9751-60826cdb0235	c6d58031-8ace-400d-ae2b-17e34e4ad6da
deab7ba7-051f-4b69-9751-60826cdb0235	341a7730-88f0-472a-a4b2-8331b27a2cae
851238e7-440d-435e-b6a1-28f7ec7438be	b331cb8b-7571-4448-8997-f554cf28a071
851238e7-440d-435e-b6a1-28f7ec7438be	63677a90-addf-4dbd-af43-a8aad6189fd1
851238e7-440d-435e-b6a1-28f7ec7438be	cfbb1614-1da5-44f7-8822-e5245ac8f1f2
851238e7-440d-435e-b6a1-28f7ec7438be	d0e1ae95-e48c-4198-ba63-1e3797393834
851238e7-440d-435e-b6a1-28f7ec7438be	209c4c85-8ad8-4f48-a127-1fe037eb32d1
851238e7-440d-435e-b6a1-28f7ec7438be	7fc4814e-5acf-4fe2-ac5c-306ddd636d51
851238e7-440d-435e-b6a1-28f7ec7438be	ffb33565-7167-4a4c-8265-db53a20e27a6
851238e7-440d-435e-b6a1-28f7ec7438be	dbd3fad8-bca9-4b97-89de-7f78ebdf9276
851238e7-440d-435e-b6a1-28f7ec7438be	341a7730-88f0-472a-a4b2-8331b27a2cae
851238e7-440d-435e-b6a1-28f7ec7438be	c6d58031-8ace-400d-ae2b-17e34e4ad6da
af6dc109-7d93-42cc-81e7-a97811afba58	63677a90-addf-4dbd-af43-a8aad6189fd1
af6dc109-7d93-42cc-81e7-a97811afba58	578b0ffe-0181-4c17-b1d6-4b26bafe6182
af6dc109-7d93-42cc-81e7-a97811afba58	9ad50c17-52a8-49d5-bfe9-09985d91c276
af6dc109-7d93-42cc-81e7-a97811afba58	cfbb1614-1da5-44f7-8822-e5245ac8f1f2
807c6cd5-8f50-4c01-b5e8-494df00b8878	8a2ee480-dd13-46b4-96f6-98c6077cc5df
807c6cd5-8f50-4c01-b5e8-494df00b8878	7b5859e5-0b3e-4381-aa2e-fe9eb6643593
807c6cd5-8f50-4c01-b5e8-494df00b8878	cd1adcb4-1282-4a9e-9399-5547d1a61115
a0a6a379-6fcf-4ee1-b718-809c509595bb	8a2ee480-dd13-46b4-96f6-98c6077cc5df
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, is_system, created_at, updated_at) FROM stdin;
1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	system_administrator	Full control over the entire system.	t	2026-08-08 14:16:04.25	2026-08-08 23:23:00.348
728f14cc-a459-47e9-99d4-d07e12e97a36	hr_officer	Manages employee records and HR reports.	t	2026-08-08 14:16:05.614	2026-08-08 23:23:02.107
ac0ce30a-9b7a-4872-b7d4-97806fb6e494	dean	Institutional oversight and analytics.	t	2026-08-08 14:16:05.963	2026-08-08 23:23:02.517
deab7ba7-051f-4b69-9751-60826cdb0235	registrar	Manages academic records, students, and grade publishing.	t	2026-08-08 14:16:06.202	2026-08-08 23:23:02.783
851238e7-440d-435e-b6a1-28f7ec7438be	department_head	Manages a department's instructors and grade approvals.	t	2026-08-08 14:16:06.562	2026-08-08 23:23:03.26
af6dc109-7d93-42cc-81e7-a97811afba58	instructor	Enters and submits grades for assigned courses.	t	2026-08-08 14:16:06.935	2026-08-08 23:23:03.714
807c6cd5-8f50-4c01-b5e8-494df00b8878	employee	Views own profile and documents.	t	2026-08-08 14:16:07.106	2026-08-08 23:23:03.914
a0a6a379-6fcf-4ee1-b718-809c509595bb	student	Views own academic information (future module).	t	2026-08-08 14:16:07.262	2026-08-08 23:23:04.12
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sections (id, course_id, semester_id, section_label, capacity, created_at, updated_at, created_by, updated_by, deleted_at, version) FROM stdin;
f69f8065-86c2-406e-8841-a2c12d5bd501	b5dd1601-82b9-4b75-bf5a-26e32a947822	bcbab3f7-fee5-4fa0-bca1-914b3a60a822	A	80	2026-08-08 19:39:29.831	2026-08-08 19:39:29.831	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0
\.


--
-- Data for Name: semesters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.semesters (id, academic_year_id, name, sequence, start_date, end_date, status, created_at, updated_at, created_by, updated_by, deleted_at, version) FROM stdin;
bcbab3f7-fee5-4fa0-bca1-914b3a60a822	bcab514a-2cd1-4e44-a5a8-7096f73a245d	Semester 1	1	2018-01-08	2018-06-08	active	2026-08-08 15:41:26.068	2026-08-08 15:41:26.068	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	0
\.


--
-- Data for Name: student_number_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_number_sequences (year, last_value) FROM stdin;
2026	1
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, student_number, first_name, middle_name, last_name, gender, date_of_birth, email, phone_number, department_id, program_id, batch, section, current_semester_id, status, created_at, updated_at, created_by, updated_by, deleted_at, version, photo_storage_key) FROM stdin;
8bfacc90-3a32-4934-b34d-cb3bb135b8cc	DBPC-STU-2026-00001	Meseret	Irko	Angesha	male	\N	\N	0945105592	a104db70-d76b-4061-9f72-51d2d574605b	18804f06-c453-4a08-af69-8888fb80b8f5	\N	A	\N	active	2026-08-08 19:43:23.385	2026-08-08 23:25:44.016	845524a5-2d8d-47e0-a279-476df7c604c7	845524a5-2d8d-47e0-a279-476df7c604c7	\N	1	students/8bfacc90-3a32-4934-b34d-cb3bb135b8cc/photo/c6e6f1c6-55b0-4b14-985c-aa0ca253d74c.jpg
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (key, value, description, updated_by, updated_at) FROM stdin;
retirement_age	60	Age at which an employee appears in the Retirement List report.	\N	2026-08-08 19:51:28.825
contract_expiry_window_days	60	Default number of days ahead the Contract Expiry report looks.	\N	2026-08-08 19:51:28.866
institution_name	Donna Barbar Polytechnic College	Institution name shown on printed documents and reports.	\N	2026-08-08 19:51:28.927
student_id_prefix	DBPC-STU	Prefix for auto-generated student IDs, e.g. DBPC-STU-2026-00001.	\N	2026-08-08 19:51:28.965
employee_id_prefix	DBPC-EMP	Prefix for auto-generated employee IDs, e.g. DBPC-EMP-2026-00001.	\N	2026-08-08 19:51:29.004
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id, assigned_at) FROM stdin;
845524a5-2d8d-47e0-a279-476df7c604c7	1f5e5f1a-04ef-4d8e-9704-32debcdcce6f	2026-08-08 16:02:08.489
3aada072-6af7-440f-b53d-4fd66be62a3a	ac0ce30a-9b7a-4872-b7d4-97806fb6e494	2026-08-08 16:35:36.43
5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	af6dc109-7d93-42cc-81e7-a97811afba58	2026-08-08 19:40:55.083
e9b42419-ded4-4ec3-8a18-1606a758ced4	deab7ba7-051f-4b69-9751-60826cdb0235	2026-08-08 23:04:39.589
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, full_name, is_active, must_change_password, failed_login_count, locked_until, token_version, last_login_at, created_at, updated_at, deleted_at, version) FROM stdin;
e9b42419-ded4-4ec3-8a18-1606a758ced4	registrar@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$pNBf/HOwbalK+sNvVu9bdw$uTHYQxzuDC/n80V/SN3NaWW0GEvwbnoHRflNcibhBSM	Reg Bater	t	f	0	\N	1	2026-08-09 01:15:12.31	2026-08-08 23:04:39.589	2026-08-09 01:15:12.311	\N	0
845524a5-2d8d-47e0-a279-476df7c604c7	booneeraa9@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$12Yrwy02Ivq9GCdwCJxe5g$QndYqq8sPU/u43rV3sYZo3kVNFNuJK5PTPGpjHqFmsM	System Administrator	t	f	0	\N	3	2026-08-09 01:15:36.202	2026-08-08 14:16:08.408	2026-08-09 01:15:36.203	\N	1
3aada072-6af7-440f-b53d-4fd66be62a3a	beketmitiku@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$/bo+HHDeSI+mbNpcNnBBow$UlCYZ2YVSRQyWMpT/msMqSQrW0Lr4eIIZxg/aZpUaks	Bonera Mitiku Amenu	t	t	1	\N	1	\N	2026-08-08 16:02:48.461	2026-08-08 16:36:37.501	\N	1
5195e4d6-af21-4d28-a2a7-ee031cb8e6f7	kenaket@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$hF4SjTggoAvCJRUTLlDZGg$+RBxPpIK5nNSZWjvYLjdP1X6gm1GxaMZowYF9QR2/y4	Booneeraa ADMIN	t	f	0	\N	2	2026-08-08 22:33:27.708	2026-08-08 19:40:55.083	2026-08-08 22:33:27.709	\N	0
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: document_verifications document_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_verifications
    ADD CONSTRAINT document_verifications_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: emergency_contacts emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_pkey PRIMARY KEY (id);


--
-- Name: employee_education employee_education_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_education
    ADD CONSTRAINT employee_education_pkey PRIMARY KEY (id);


--
-- Name: employee_number_sequences employee_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_number_sequences
    ADD CONSTRAINT employee_number_sequences_pkey PRIMARY KEY (year);


--
-- Name: employee_qualifications employee_qualifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_qualifications
    ADD CONSTRAINT employee_qualifications_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employment_history employment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employment_history
    ADD CONSTRAINT employment_history_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: grade_components grade_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_components
    ADD CONSTRAINT grade_components_pkey PRIMARY KEY (id);


--
-- Name: grade_entries grade_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_entries
    ADD CONSTRAINT grade_entries_pkey PRIMARY KEY (id);


--
-- Name: grade_results grade_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_results
    ADD CONSTRAINT grade_results_pkey PRIMARY KEY (id);


--
-- Name: grade_submissions grade_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_submissions
    ADD CONSTRAINT grade_submissions_pkey PRIMARY KEY (id);


--
-- Name: grading_scale_bands grading_scale_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grading_scale_bands
    ADD CONSTRAINT grading_scale_bands_pkey PRIMARY KEY (id);


--
-- Name: grading_scales grading_scales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grading_scales
    ADD CONSTRAINT grading_scales_pkey PRIMARY KEY (id);


--
-- Name: instructor_assignments instructor_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instructor_assignments
    ADD CONSTRAINT instructor_assignments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: semesters semesters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesters
    ADD CONSTRAINT semesters_pkey PRIMARY KEY (id);


--
-- Name: student_number_sequences student_number_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_number_sequences
    ADD CONSTRAINT student_number_sequences_pkey PRIMARY KEY (year);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: academic_years_is_current_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX academic_years_is_current_idx ON public.academic_years USING btree (is_current);


--
-- Name: academic_years_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX academic_years_name_key ON public.academic_years USING btree (name);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_type_entity_id_idx ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: courses_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courses_code_idx ON public.courses USING btree (code);


--
-- Name: courses_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX courses_code_key ON public.courses USING btree (code);


--
-- Name: courses_program_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courses_program_id_idx ON public.courses USING btree (program_id);


--
-- Name: departments_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX departments_code_idx ON public.departments USING btree (code);


--
-- Name: departments_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX departments_code_key ON public.departments USING btree (code);


--
-- Name: departments_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX departments_is_active_idx ON public.departments USING btree (is_active);


--
-- Name: document_verifications_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_verifications_code_key ON public.document_verifications USING btree (code);


--
-- Name: document_verifications_subject_type_subject_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_verifications_subject_type_subject_id_idx ON public.document_verifications USING btree (subject_type, subject_id);


--
-- Name: documents_owner_type_owner_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_owner_type_owner_id_idx ON public.documents USING btree (owner_type, owner_id);


--
-- Name: emergency_contacts_employee_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emergency_contacts_employee_id_idx ON public.emergency_contacts USING btree (employee_id);


--
-- Name: employee_education_employee_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employee_education_employee_id_idx ON public.employee_education USING btree (employee_id);


--
-- Name: employee_qualifications_employee_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employee_qualifications_employee_id_idx ON public.employee_qualifications USING btree (employee_id);


--
-- Name: employees_department_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_department_id_idx ON public.employees USING btree (department_id);


--
-- Name: employees_employee_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_employee_number_idx ON public.employees USING btree (employee_number);


--
-- Name: employees_employee_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX employees_employee_number_key ON public.employees USING btree (employee_number);


--
-- Name: employees_employment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_employment_status_idx ON public.employees USING btree (employment_status);


--
-- Name: employees_last_name_first_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_last_name_first_name_idx ON public.employees USING btree (last_name, first_name);


--
-- Name: employment_history_employee_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employment_history_employee_id_idx ON public.employment_history USING btree (employee_id);


--
-- Name: enrollments_section_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enrollments_section_id_idx ON public.enrollments USING btree (section_id);


--
-- Name: enrollments_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enrollments_student_id_idx ON public.enrollments USING btree (student_id);


--
-- Name: enrollments_student_id_section_id_attempt_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX enrollments_student_id_section_id_attempt_number_key ON public.enrollments USING btree (student_id, section_id, attempt_number);


--
-- Name: grade_components_department_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grade_components_department_id_idx ON public.grade_components USING btree (department_id);


--
-- Name: grade_entries_enrollment_id_component_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX grade_entries_enrollment_id_component_id_key ON public.grade_entries USING btree (enrollment_id, component_id);


--
-- Name: grade_entries_enrollment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grade_entries_enrollment_id_idx ON public.grade_entries USING btree (enrollment_id);


--
-- Name: grade_results_enrollment_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX grade_results_enrollment_id_key ON public.grade_results USING btree (enrollment_id);


--
-- Name: grade_submissions_section_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX grade_submissions_section_id_key ON public.grade_submissions USING btree (section_id);


--
-- Name: grading_scale_bands_scale_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grading_scale_bands_scale_id_idx ON public.grading_scale_bands USING btree (scale_id);


--
-- Name: grading_scales_department_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX grading_scales_department_id_idx ON public.grading_scales USING btree (department_id);


--
-- Name: instructor_assignments_instructor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX instructor_assignments_instructor_id_idx ON public.instructor_assignments USING btree (instructor_id);


--
-- Name: instructor_assignments_section_id_instructor_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX instructor_assignments_section_id_instructor_id_key ON public.instructor_assignments USING btree (section_id, instructor_id);


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: programs_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programs_code_idx ON public.programs USING btree (code);


--
-- Name: programs_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX programs_code_key ON public.programs USING btree (code);


--
-- Name: programs_department_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programs_department_id_idx ON public.programs USING btree (department_id);


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX refresh_tokens_token_hash_key ON public.refresh_tokens USING btree (token_hash);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: role_permissions_permission_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX role_permissions_permission_id_idx ON public.role_permissions USING btree (permission_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sections_course_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sections_course_id_idx ON public.sections USING btree (course_id);


--
-- Name: sections_course_id_semester_id_section_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sections_course_id_semester_id_section_label_key ON public.sections USING btree (course_id, semester_id, section_label);


--
-- Name: sections_semester_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sections_semester_id_idx ON public.sections USING btree (semester_id);


--
-- Name: semesters_academic_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX semesters_academic_year_id_idx ON public.semesters USING btree (academic_year_id);


--
-- Name: semesters_academic_year_id_sequence_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX semesters_academic_year_id_sequence_key ON public.semesters USING btree (academic_year_id, sequence);


--
-- Name: students_department_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_department_id_idx ON public.students USING btree (department_id);


--
-- Name: students_last_name_first_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_last_name_first_name_idx ON public.students USING btree (last_name, first_name);


--
-- Name: students_program_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_program_id_idx ON public.students USING btree (program_id);


--
-- Name: students_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_status_idx ON public.students USING btree (status);


--
-- Name: students_student_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX students_student_number_idx ON public.students USING btree (student_number);


--
-- Name: students_student_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX students_student_number_key ON public.students USING btree (student_number);


--
-- Name: user_roles_role_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_idx ON public.user_roles USING btree (role_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: courses courses_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: emergency_contacts emergency_contacts_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employee_education employee_education_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_education
    ADD CONSTRAINT employee_education_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employee_qualifications employee_qualifications_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_qualifications
    ADD CONSTRAINT employee_qualifications_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_supervisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_supervisor_id_fkey FOREIGN KEY (supervisor_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employment_history employment_history_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employment_history
    ADD CONSTRAINT employment_history_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollments enrollments_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollments enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grade_entries grade_entries_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_entries
    ADD CONSTRAINT grade_entries_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.grade_components(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grade_entries grade_entries_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_entries
    ADD CONSTRAINT grade_entries_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grade_results grade_results_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_results
    ADD CONSTRAINT grade_results_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grade_submissions grade_submissions_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grade_submissions
    ADD CONSTRAINT grade_submissions_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grading_scale_bands grading_scale_bands_scale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grading_scale_bands
    ADD CONSTRAINT grading_scale_bands_scale_id_fkey FOREIGN KEY (scale_id) REFERENCES public.grading_scales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: instructor_assignments instructor_assignments_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instructor_assignments
    ADD CONSTRAINT instructor_assignments_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: instructor_assignments instructor_assignments_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instructor_assignments
    ADD CONSTRAINT instructor_assignments_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: programs programs_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sections sections_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sections sections_semester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES public.semesters(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: semesters semesters_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semesters
    ADD CONSTRAINT semesters_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: students students_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.programs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict h6a7Rv8IPPO8507pcI4r8nVieAEcs22ssCc2I6AlLfTVNAqEVsq9pp4cWmrHoMc

